﻿namespace Wati.Api.Models
{
    public class RequestData
    {
        public int Num1 { get; set; }
        public int Num2 { get; set; }
    }
}